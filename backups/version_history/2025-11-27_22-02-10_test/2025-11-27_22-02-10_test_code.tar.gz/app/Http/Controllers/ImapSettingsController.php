<?php

namespace App\Http\Controllers;

use App\Models\ImapSetting;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;
use Webklex\PHPIMAP\ClientManager;

class ImapSettingsController extends Controller
{
    public function __construct() { $this->middleware('auth'); }

    public function edit() {
        $s = ImapSetting::singleton();

        $raw_list = is_array($s->last_folders_cache) ? $s->last_folders_cache : array();
        $folders = array();
        $i = 0;
        foreach ($raw_list as $item) {
            if (is_array($item) && isset($item['value'])) {
                $val = (string)$item['value'];
                $label = isset($item['label']) ? (string)$item['label'] : $this->humanLabel($val);
            } else {
                $val = (string)$item;
                $label = $this->humanLabel($val);
            }
            $folders[] = array('value' => $val, 'label' => $label);
            $i++;
        }

        $log = $s->last_test_log ? $s->last_test_log : '';
        return view('settings.imap.edit', compact('s','folders','log'));
    }

    public function update(Request $request) {
        $s = ImapSetting::singleton();

        $data = $request->validate(array(
            'host' => array('nullable','string','max:255'),
            'port' => array('nullable','integer','min:1','max:65535'),
            'encryption' => array('required', Rule::in(array('none','ssl','tls'))),
            'username' => array('nullable','string','max:255'),
            'password' => array('nullable','string','max:4096'),
            'enabled' => array('nullable','boolean'),
            'poll_minutes' => array('required','integer','min:1','max:10080'),
            'selected_folders' => array('nullable','array'),
            'selected_folders.*' => array('string','max:255'),
        ));

        if (!isset($data['password']) || $data['password'] === '') {
            unset($data['password']);
        }

        $s->fill($data);
        $s->enabled = $request->has('enabled') ? (bool)$request->input('enabled') : false;

        if ($request->has('selected_folders') && is_array($request->input('selected_folders'))) {
            $s->selected_folders = array_values($request->input('selected_folders'));
        }

        $s->save();
        return back()->with('status', 'IMAP settings saved.');
    }

    public function test(Request $request) {
        $s = ImapSetting::singleton();
        $cfg = $this->buildRuntimeConfig($request, $s);

        $log = '';
        try {
            $cm = new ClientManager();
            $client = $cm->make($cfg);
            $client->connect();

            $encLabel = 'none';
            if (isset($cfg['encryption']) && $cfg['encryption']) { $encLabel = $cfg['encryption']; }

            $log .= 'Connected OK to '.$cfg['host'].':'.$cfg['port'].' ('.$encLabel.")\n";
            $client->disconnect();
        } catch (\Throwable $e) {
            $log .= 'ERROR: '.$e->getMessage()."\n";
        }

        $s->last_test_log = $log;
        $s->save();

        return back()->with('status', 'Test finished. See log.');
    }

    public function fetchFolders(Request $request) {
        $s = ImapSetting::singleton();
        $cfg = $this->buildRuntimeConfig($request, $s);

        $log = '';
        $out = array();
        $seen = array();

        try {
            $cm = new ClientManager();
            $client = $cm->make($cfg);
            $client->connect();

            $folders = $client->getFolders(false);
            foreach ($folders as $f) {
                $raw = '';
                if (isset($f->path) && $f->path) { $raw = (string)$f->path; }
                elseif (isset($f->full_name) && $f->full_name) { $raw = (string)$f->full_name; }
                elseif (isset($f->fullName) && $f->fullName) { $raw = (string)$f->fullName; }
                else { $raw = (string)$f->name; }

                $val = $raw;                              // exact server path
                $label = $this->humanLabel($raw);         // pretty label with arrows

                if (!isset($seen[$val])) {
                    $out[] = array('value' => $val, 'label' => $label);
                    $seen[$val] = true;
                }
            }

            // Sort by pretty label
            usort($out, function($a,$b){
                $la = isset($a['label']) ? $a['label'] : '';
                $lb = isset($b['label']) ? $b['label'] : '';
                return strcasecmp($la, $lb);
            });

            $log .= 'Fetched '.count($out).' folder(s).'."\n";
            $client->disconnect();
        } catch (\Throwable $e) {
            $log .= 'ERROR: '.$e->getMessage()."\n";
        }

        $s->last_folders_cache = $out;   // store as [{value, label}, ...]
        $s->last_test_log = $log;
        $s->save();

        return back()->with('status', 'Folders updated. See log.');
    }

    private function buildRuntimeConfig(Request $request, ImapSetting $s): array {
        $host = $s->host;
        if ($request->has('host')) { $host = (string)$request->input('host'); }

        $port = $s->port ? (int)$s->port : 993;
        if ($request->has('port')) { $port = (int)$request->input('port'); }

        $enc = $s->encryption ? (string)$s->encryption : 'ssl';
        if ($request->has('encryption')) { $enc = (string)$request->input('encryption'); }

        $username = $s->username;
        if ($request->has('username')) { $username = (string)$request->input('username'); }

        $password = $s->password;
        if ($request->filled('password')) { $password = (string)$request->input('password'); }

        $encryption = null;
        if ($enc !== 'none') { $encryption = $enc; }

        return array(
            'host'          => $host,
            'port'          => $port,
            'encryption'    => $encryption,
            'validate_cert' => true,
            'username'      => $username,
            'password'      => $password,
            'protocol'      => 'imap',
            'options'       => array('fetch_order' => 'newest'),
            'common_folders'=> false,
        );
    }

    private function humanLabel($raw) {
        $s = (string)$raw;
        // Replace common IMAP delimiters with arrows
        $s = str_replace('\\', '/', $s);
        $parts = preg_split('/[\/\.]+/', $s);
        if (!is_array($parts)) { return $s; }
        // Optionally hide leading INBOX if followed by something
        if (count($parts) > 1 && strtoupper($parts[0]) === 'INBOX') {
            array_shift($parts);
        }
        return implode(' → ', $parts);
    }
}
