#!/usr/bin/env bash
set -euo pipefail

##
## Roll back code + DB to a previously captured snapshot.
##
## Usage:
##   ./scripts/version_rollback.sh SNAPSHOT_ID
##
## When called from the UI, NON_INTERACTIVE=1 is set and the confirmation
## prompt is skipped.
##

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

SNAPSHOT_ID="${1:-}"

if [[ -z "$SNAPSHOT_ID" ]]; then
  echo "Usage: $0 SNAPSHOT_ID" >&2
  exit 1
fi

SNAPSHOT_DIR="$ROOT/backups/version_history/$SNAPSHOT_ID"
DB_DUMP="$SNAPSHOT_DIR/db.sql.gz"
CODE_ARCHIVE="$SNAPSHOT_DIR/code.tar.gz"

if [[ ! -d "$SNAPSHOT_DIR" ]]; then
  echo "ERROR: Snapshot directory not found: $SNAPSHOT_DIR" >&2
  exit 1
fi

if [[ ! -f "$DB_DUMP" ]]; then
  echo "ERROR: DB dump not found: $DB_DUMP" >&2
  exit 1
fi

if [[ ! -f "$CODE_ARCHIVE" ]]; then
  echo "ERROR: Code archive not found: $CODE_ARCHIVE" >&2
  exit 1
fi

echo "==> Preparing to restore snapshot: $SNAPSHOT_ID"
echo "    From directory: $SNAPSHOT_DIR"
echo
echo "This will:"
echo "  - Backup current code under backups/pre_rollback_*/ (best effort)"
echo "  - Overwrite the project tree with the archived code"
echo "  - Restore the Postgres database from the snapshot dump"
echo

if [[ "${NON_INTERACTIVE:-0}" != "1" ]]; then
  read -r -p "Type YES to confirm: " answer

  if [[ "$answer" != "YES" ]]; then
    echo "Aborted."
    exit 1
  fi
else
  echo "==> NON_INTERACTIVE=1 set, skipping interactive confirmation."
fi

# Best-effort pre-rollback backup of current code.
PRE_DIR="$ROOT/backups/pre_rollback_$(date -u +%F_%H-%M-%S)"

if mkdir -p "$PRE_DIR"; then
  echo "==> Backing up current code to: $PRE_DIR"
  if ! tar \
    --ignore-failed-read \
    --exclude='./backups' \
    --exclude='./.backups' \
    --exclude='./vendor' \
    --exclude='./node_modules' \
    --exclude='./.git' \
    -czf "$PRE_DIR/code_before.tar.gz" .; then
    echo "WARNING: Pre-rollback code backup tar failed; continuing WITHOUT pre-rollback backup." >&2
  fi
else
  echo "WARNING: Could not create pre-rollback backup directory: $PRE_DIR" >&2
  echo "         Continuing WITHOUT pre-rollback code backup." >&2
fi

# Make sure Postgres is up (service name: postgres)
echo "==> Ensuring Postgres service is up..."
docker compose up -d postgres >/dev/null 2>&1 || true

if ! docker compose ps --services --filter "status=running" | grep -qx 'postgres'; then
  echo "ERROR: postgres service is not running." >&2
  echo "       Start it with:" >&2
  echo "         docker compose up -d postgres" >&2
  exit 1
fi

# Stop app + web (keep DB up)
echo "==> Stopping app and web services..."
docker compose stop app web >/dev/null 2>&1 || true

# Restore code
echo "==> Restoring application code from snapshot..."
tar -xzf "$CODE_ARCHIVE" -C "$ROOT"

# Restore DB
echo "==> Restoring Postgres database from snapshot..."
gunzip -c "$DB_DUMP" | docker compose exec -T postgres sh -lc '
  set -euo pipefail
  : "${POSTGRES_DB:?POSTGRES_DB not set}"
  : "${POSTGRES_USER:?POSTGRES_USER not set}"
  psql -U "$POSTGRES_USER" "$POSTGRES_DB"
'

# Start app + web again
echo "==> Starting app and web services..."
docker compose up -d app web >/dev/null 2>&1 || true

echo "==> Rollback complete. Snapshot restored: $SNAPSHOT_ID"
