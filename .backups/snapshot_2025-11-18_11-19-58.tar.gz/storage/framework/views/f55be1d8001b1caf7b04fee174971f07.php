<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
   <?php $__env->slot('header', null, []); ?> 
    <h2 class="font-semibold text-xl text-gray-800 leading-tight">
      Drop Down: <?php echo e($menu->title); ?> — Items
    </h2>
   <?php $__env->endSlot(); ?>

  <div class="max-w-4xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
    <?php if(session('status')): ?>
      <div class="mb-4 rounded border bg-green-50 text-green-700 px-3 py-2">
        <?php echo e(session('status')); ?>

      </div>
    <?php endif; ?>

    <form method="POST" action="<?php echo e(route('settings.dropdowns.items.store', $menu)); ?>" class="mb-6 flex gap-2">
      <?php echo csrf_field(); ?>
      <input name="label" class="border rounded px-3 py-2 w-full" placeholder="New item label..." required>
      <button class="rounded bg-blue-600 text-white px-4 py-2 hover:bg-blue-700">Add</button>
    </form>

    <div class="mb-2 text-sm text-gray-600">
      Drag items to reorder. Changes save automatically.
    </div>

    <ul id="sortable-list" class="bg-white border rounded divide-y">
      <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li class="flex items-center justify-between gap-3 px-3 py-2"
            data-id="<?php echo e($item->id); ?>" draggable="true">
          <div class="flex items-center gap-2">
            <span class="cursor-grab select-none" aria-hidden="true">⋮⋮</span>
            <span><?php echo e($item->label); ?></span>
          </div>
          <div class="flex items-center gap-2">
            <a href="<?php echo e(route('settings.dropdowns.items.edit', [$menu, $item])); ?>"
               class="text-sm px-2 py-1 border rounded hover:bg-gray-50">Edit</a>
            <form method="POST" action="<?php echo e(route('settings.dropdowns.items.destroy', [$menu, $item])); ?>"
                  onsubmit="return confirm('Delete this item?')">
              <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
              <button class="text-sm px-2 py-1 border rounded hover:bg-gray-50">Delete</button>
            </form>
          </div>
        </li>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>

    <div id="save-status" class="mt-3 hidden text-sm"></div>

    <div class="mt-8">
      <a href="<?php echo e(route('settings.dropdowns.index')); ?>" class="text-sm text-blue-700 hover:underline">← Back to all menus</a>
    </div>
  </div>

  <script src="<?php echo e(asset('js/dnd-reorder.js')); ?>" defer></script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /var/www/html/resources/views/settings/dropdowns/items/index.blade.php ENDPATH**/ ?>