<?php if(session('status')): ?>
  <div class="mb-3 rounded border border-green-300 bg-green-50 p-3 text-green-800">
    <?php echo e(session('status')); ?>

  </div>
<?php endif; ?>
<?php if(session('error')): ?>
  <div class="mb-3 rounded border border-red-300 bg-red-50 p-3 text-red-800">
    <?php echo e(session('error')); ?>

  </div>
<?php endif; ?>
<?php if(session('log')): ?>
  <div class="mb-4 rounded border border-gray-300 bg-gray-50 p-3 text-gray-800">
    <div class="font-semibold mb-1">Log</div>
    <ul class="list-disc ml-5 text-sm">
      <?php $__currentLoopData = session('log'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $line): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($line); ?></li>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
  </div>
<?php endif; ?>
<?php /**PATH /var/www/html/resources/views/partials/flash_log.blade.php ENDPATH**/ ?>