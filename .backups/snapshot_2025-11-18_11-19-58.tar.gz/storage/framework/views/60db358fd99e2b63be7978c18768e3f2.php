<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
   <?php $__env->slot('header', null, []); ?> 
    <h2 class="font-semibold text-xl text-gray-800 leading-tight">IMAP Settings</h2>
   <?php $__env->endSlot(); ?>

  <div class="py-6 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
    <?php if(session('status')): ?>
      <div class="mb-4 rounded border bg-green-50 text-green-800 px-4 py-2 text-sm">
        <?php echo e(session('status')); ?>

      </div>
    <?php endif; ?>
    <?php if($errors->any()): ?>
      <div class="mb-4 rounded border bg-red-50 text-red-800 px-4 py-2 text-sm">
        <ul class="list-disc ms-5">
          <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
      </div>
    <?php endif; ?>

    <?php
      $selected = old('selected_folders', is_array($s->selected_folders) ? $s->selected_folders : []);
      if (!is_array($selected)) { $selected = []; }
      $enabled = old('enabled', $s->enabled ? 1 : 0) ? true : false;
    ?>

    <form method="POST" action="<?php echo e(route('settings.imap.update')); ?>" class="space-y-6">
      <?php echo csrf_field(); ?>
      <?php echo method_field('PUT'); ?>

      <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div>
          <label class="block text-sm font-medium text-gray-700">Host</label>
          <input name="host" type="text" class="mt-1 w-full rounded border px-3 py-2"
                 value="<?php echo e(old('host', $s->host)); ?>">
        </div>

        <div>
          <label class="block text-sm font-medium text-gray-700">Port</label>
          <input name="port" type="number" min="1" max="65535" class="mt-1 w-full rounded border px-3 py-2"
                 value="<?php echo e(old('port', $s->port ?: 993)); ?>">
        </div>

        <div>
          <label class="block text-sm font-medium text-gray-700">Encryption</label>
          <?php $enc = old('encryption', $s->encryption ?: 'ssl'); ?>
          <select name="encryption" class="mt-1 w-full rounded border px-3 py-2">
            <option value="none" <?php echo e($enc === 'none' ? 'selected' : ''); ?>>None</option>
            <option value="ssl"  <?php echo e($enc === 'ssl'  ? 'selected' : ''); ?>>SSL</option>
            <option value="tls"  <?php echo e($enc === 'tls'  ? 'selected' : ''); ?>>TLS</option>
          </select>
        </div>

        <div>
          <label class="block text-sm font-medium text-gray-700">Username</label>
          <input name="username" type="text" class="mt-1 w-full rounded border px-3 py-2"
                 value="<?php echo e(old('username', $s->username)); ?>">
        </div>

        <div>
          <label class="block text-sm font-medium text-gray-700">Password <span class="text-gray-400">(leave blank to keep)</span></label>
          <input name="password" type="password" class="mt-1 w-full rounded border px-3 py-2" autocomplete="new-password">
        </div>

        <div>
          <label class="block text-sm font-medium text-gray-700">Polling every (minutes)</label>
          <input name="poll_minutes" type="number" min="1" max="10080" class="mt-1 w-full rounded border px-3 py-2"
                 value="<?php echo e(old('poll_minutes', $s->poll_minutes ?: 5)); ?>">
        </div>

        <div class="md:col-span-3">
          <div class="flex flex-wrap items-center gap-3">
            <label class="inline-flex items-center gap-2">
              <input type="checkbox" name="enabled" value="1" <?php echo e($enabled ? 'checked' : ''); ?>>
              <span class="text-sm text-gray-700">Fetching enabled (start polling loop)</span>
            </label>

            <?php if($enabled): ?>
              <div class="inline-flex items-center gap-2 text-xs rounded border bg-gray-50 px-2 py-1">
                <span class="text-gray-600">Last run:</span>
                <span class="font-medium text-gray-900">
                  <?php if($s->last_run_at): ?>
                    <?php echo e($s->last_run_at->format('d/m/Y H:i')); ?>

                  <?php else: ?>
                    —
                  <?php endif; ?>
                </span>
              </div>
            <?php endif; ?>
          </div>
        </div>
      </div>

      <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <label class="block text-sm font-medium text-gray-700 mb-1">Monitor folders (multi-select)</label>
          <select name="selected_folders[]" multiple size="12" class="w-full rounded border px-2 py-2">
            <?php $__currentLoopData = ($folders ?? []); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php
                $val = is_array($opt) && isset($opt['value']) ? $opt['value'] : (string)$opt;
                $label = is_array($opt) && isset($opt['label']) ? $opt['label'] : $val;
                $isSelected = in_array($val, $selected, true);
              ?>
              <option value="<?php echo e($val); ?>" <?php echo e($isSelected ? 'selected' : ''); ?>>
                <?php echo e($label); ?>

              </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
          <p class="text-xs text-gray-500 mt-2">Use Ctrl/⌘ or Shift to select multiple. Click “Fetch folders” to refresh.</p>
        </div>

        <div>
          <label class="block text-sm font-medium text-gray-700 mb-1">Test / Fetch log</label>
          <pre class="w-full rounded border bg-gray-50 p-3 text-xs whitespace-pre-wrap" style="min-height: 12rem"><?php echo e($log); ?></pre>
        </div>
      </div>

      <div class="flex items-center gap-3">
        <button type="submit"
                class="rounded bg-blue-600 px-4 py-2 text-white hover:bg-blue-700 focus:outline-none focus:ring"
        >Save settings</button>

        <button type="submit"
                formaction="<?php echo e(route('settings.imap.test')); ?>"
                formmethod="POST"
                class="rounded bg-blue-600 px-4 py-2 text-white hover:bg-blue-700 focus:outline-none focus:ring"
        >Test connection</button>

        <button type="submit"
                formaction="<?php echo e(route('settings.imap.fetch')); ?>"
                formmethod="POST"
                class="rounded bg-blue-600 px-4 py-2 text-white hover:bg-blue-700 focus:outline-none focus:ring"
        >Fetch folders</button>
        <?php echo csrf_field(); ?>
      </div>
    </form>
  </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /var/www/html/resources/views/settings/imap/edit.blade.php ENDPATH**/ ?>