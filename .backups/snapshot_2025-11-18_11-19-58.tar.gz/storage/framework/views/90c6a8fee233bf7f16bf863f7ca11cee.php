<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="section-title"><?php echo e(__('Authentication Logs')); ?></h2>
        <p class="section-subtitle"><?php echo e(__('Recent sign-ins and sign-outs')); ?></p>
     <?php $__env->endSlot(); ?>

    <div class="card overflow-x-auto">
        <table class="min-w-full text-sm">
            <thead class="text-left text-gray-600">
                <tr>
                    <th class="py-2 pe-4"><?php echo e(__('When')); ?></th>
                    <th class="py-2 pe-4"><?php echo e(__('User')); ?></th>
                    <th class="py-2 pe-4"><?php echo e(__('Event')); ?></th>
                    <th class="py-2 pe-4"><?php echo e(__('IP')); ?></th>
                    <th class="py-2 pe-4"><?php echo e(__('User-Agent')); ?></th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-200">
                <?php $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="py-2 pe-4 text-gray-800"><?php echo e($log->created_at->format('Y-m-d H:i:s')); ?></td>
                    <td class="py-2 pe-4">
                        <?php if($log->user): ?>
                            <span class="font-medium text-gray-900"><?php echo e($log->user->name); ?></span>
                            <span class="text-gray-500">(<?php echo e($log->user->email); ?>)</span>
                        <?php else: ?>
                            <span class="text-gray-500">—</span>
                        <?php endif; ?>
                    </td>
                    <td class="py-2 pe-4">
                        <span class="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-semibold
                            <?php echo e($log->event === 'login' ? 'bg-green-100 text-green-800' : 'bg-amber-100 text-amber-800'); ?>">
                            <?php echo e(ucfirst($log->event)); ?>

                        </span>
                    </td>
                    <td class="py-2 pe-4 text-gray-700"><?php echo e($log->ip ?? '—'); ?></td>
                    <td class="py-2 pe-4 text-gray-500 max-w-[32rem] truncate" title="<?php echo e($log->user_agent); ?>"><?php echo e($log->user_agent); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

        <div class="mt-4"><?php echo e($logs->links()); ?></div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /var/www/html/resources/views/settings/logs/index.blade.php ENDPATH**/ ?>