<?php if(session('status')): ?>
<div class="bg-green-50 border border-green-200 text-green-800 rounded p-3 mb-4"><?php echo e(session('status')); ?></div>
<?php endif; ?>
<?php /**PATH /var/www/html/resources/views/components/alert.blade.php ENDPATH**/ ?>