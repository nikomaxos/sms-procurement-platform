<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
   <?php $__env->slot('header', null, []); ?> 
    <h2 class="font-semibold text-xl text-gray-800 leading-tight">Drop Down Menus</h2>
   <?php $__env->endSlot(); ?>

  <div class="py-6 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
    <div class="mb-4">
      <a href="<?php echo e(route('settings.dropdowns.create')); ?>"
         class="inline-flex items-center rounded bg-blue-600 px-4 py-2 text-white hover:bg-blue-700 text-sm">
        + New Menu
      </a>
    </div>

    <div class="overflow-hidden rounded-lg border bg-white">
      <table class="min-w-full text-sm">
        <thead class="bg-gray-50">
          <tr>
            <th class="px-4 py-2 text-left font-semibold text-gray-700">ID</th>
            <th class="px-4 py-2 text-left font-semibold text-gray-700">Title</th>
            <th class="px-4 py-2 text-left font-semibold text-gray-700">Items</th>
            <th class="px-4 py-2 text-right font-semibold text-gray-700">Actions</th>
          </tr>
        </thead>
        <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
          <tr class="border-t">
            <td class="px-4 py-2 text-gray-800"><?php echo e($menu->id); ?></td>
            <td class="px-4 py-2 text-gray-800"><?php echo e($menu->title); ?></td>
            <td class="px-4 py-2 text-gray-800"><?php echo e($menu->items_count); ?></td>
            <td class="px-4 py-2">
              <div class="flex items-center gap-2 justify-end">
                <a href="<?php echo e(route('settings.dropdowns.items.index', $menu)); ?>"
                   class="rounded border px-3 py-1.5 text-gray-700 hover:bg-gray-50">Manage items</a>
                <a href="<?php echo e(route('settings.dropdowns.edit', $menu)); ?>"
                   class="rounded border px-3 py-1.5 text-gray-700 hover:bg-gray-50">Edit</a>
                <form method="POST" action="<?php echo e(route('settings.dropdowns.destroy', $menu)); ?>"
                      onsubmit="return confirm('Delete this menu (and its items)?');">
                  <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                  <button class="rounded border px-3 py-1.5 text-red-600 hover:bg-red-50">Delete</button>
                </form>
              </div>
            </td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
          <tr class="border-t">
            <td colspan="4" class="px-4 py-6 text-center text-gray-500">No menus yet. Create one.</td>
          </tr>
        <?php endif; ?>
        </tbody>
      </table>
    </div>

    <div class="mt-4"><?php echo e($menus->links()); ?></div>
  </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /var/www/html/resources/views/settings/dropdowns/index.blade.php ENDPATH**/ ?>