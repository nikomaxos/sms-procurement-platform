<a href="<?php echo e(route('countries.index')); ?>" class="flex items-center gap-2 px-3 py-2 rounded hover:bg-gray-100">
  <span class="material-icons text-sm">public</span><span>Countries</span>
</a>
<a href="<?php echo e(route('networks.index')); ?>" class="flex items-center gap-2 px-3 py-2 rounded hover:bg-gray-100">
  <span class="material-icons text-sm">cell_tower</span><span>Networks</span>
</a>
<hr class="my-2 opacity-30" />
<?php /**PATH /var/www/html/resources/views/partials/countries_networks_links.blade.php ENDPATH**/ ?>