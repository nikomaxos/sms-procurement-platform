<nav class="bg-white border-b">
  <div class="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
    <div class="flex h-14 items-center justify-between">
      <div class="flex items-center gap-6">
        <a href="<?php echo e(url('/')); ?>" class="font-semibold text-gray-800">SMS Suppliers</a>

        <a href="<?php echo e(url('/dashboard')); ?>"
           class="text-sm <?php echo e(request()->is('dashboard') ? 'text-blue-600' : 'text-gray-700 hover:text-gray-900'); ?>">
          Dashboard
        </a>

        <div class="relative group">
          <button type="button" class="inline-flex items-center gap-2 text-sm text-gray-700 group-hover:text-gray-900">
            <span>Settings</span>
            <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
              <path fill-rule="evenodd" d="M5.23 7.21a.75.75 0 011.06.02L10 11.17l3.71-3.94a.75.75 0 111.08 1.04l-4.25 4.5a.75.75 0 01-1.08 0l-4.25-4.5a.75.75 0 01.02-1.06z" clip-rule="evenodd"/>
            </svg>
          </button>
          <div class="absolute left-0 z-50 hidden group-hover:block bg-white shadow rounded-md mt-2 min-w-56 py-1"><a href="<?php echo e(url('/settings/dropdowns')); ?>"
               class="block px-4 py-2 text-sm <?php echo e(request()->is('settings/dropdowns*') ? 'bg-gray-100 text-gray-900' : 'text-gray-700 hover:bg-gray-50'); ?>">
              Drop Down Menus
            </a>
            <a href="<?php echo e(url('/settings/imap')); ?>"
               class="block px-4 py-2 text-sm <?php echo e(request()->is('settings/imap*') ? 'bg-gray-100 text-gray-900' : 'text-gray-700 hover:bg-gray-50'); ?>">
              IMAP Settings
            </a>
            <a href="<?php echo e(url('/settings/users')); ?>"
               class="block px-4 py-2 text-sm <?php echo e(request()->is('settings/users*') ? 'bg-gray-100 text-gray-900' : 'text-gray-700 hover:bg-gray-50'); ?>">
              Users Management
            </a>
          </div>
        </div>
      </div>

      <div class="flex items-center gap-3">
        <?php if(auth()->guard()->check()): ?>
          <span class="text-sm text-gray-600"><?php echo e(auth()->user()->name); ?></span>
          <form method="POST" action="<?php echo e(route('logout')); ?>">
            <?php echo csrf_field(); ?>
            <button class="text-sm text-gray-700 hover:text-gray-900">Logout</button>
          </form>
        <?php endif; ?>
        <?php if(auth()->guard()->guest()): ?>
          <a href="<?php echo e(route('login')); ?>" class="text-sm text-gray-700 hover:text-gray-900">Login</a>
        <?php endif; ?>
      </div>
    </div>
  </div>
</nav>
<?php /**PATH /var/www/html/resources/views/partials/nav.blade.php ENDPATH**/ ?>