<?php $__env->startSection('content'); ?>
  <div class="max-w-xl mx-auto mt-16 bg-white border rounded-lg p-6">
    <h1 class="text-2xl font-semibold text-gray-800 mb-2">403 — Δεν έχετε δικαίωμα πρόσβασης</h1>
    <p class="text-gray-600 mb-6">
      Δεν έχετε πρόσβαση στη διαχείριση χρηστών. Αν χρειάζεστε δικαιώματα διαχειριστή, επικοινωνήστε με τον υπεύθυνο του συστήματος.
    </p>
    <a href="<?php echo e(route('dashboard')); ?>"
       class="inline-block px-4 py-2 rounded bg-blue-600 text-white hover:bg-blue-700">
      Επιστροφή στις Ρυθμίσεις
    </a>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/html/resources/views/errors/403.blade.php ENDPATH**/ ?>