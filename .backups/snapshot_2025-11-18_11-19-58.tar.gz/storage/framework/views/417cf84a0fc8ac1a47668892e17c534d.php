<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php echo $__env->make('partials.flash_log', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php echo $__env->make("components.flash-log", array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php echo $__env->make("components.flash-log", array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
   <?php $__env->slot('header', null, []); ?> 
    <h2 class="font-semibold text-xl text-gray-800 leading-tight">Edit Country — <?php echo e($country->name); ?></h2>
   <?php $__env->endSlot(); ?>

  <div class="py-6 max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
    <?php if(session('success')): ?> <div class="mb-4 p-3 rounded bg-green-50 text-green-700"><?php echo e(session('success')); ?></div> <?php endif; ?>
    <?php if(session('warning')): ?> <div class="mb-4 p-3 rounded bg-yellow-50 text-yellow-700"><?php echo e(session('warning')); ?></div> <?php endif; ?>
    <?php if(session('error')): ?>   <div class="mb-4 p-3 rounded bg-red-50 text-red-700"><?php echo e(session('error')); ?></div> <?php endif; ?>
    <?php if(session('info')): ?>    <div class="mb-4 p-3 rounded bg-blue-50 text-blue-700"><?php echo e(session('info')); ?></div> <?php endif; ?>

    
    <form method="POST" action="<?php echo e(route('countries.update', $country->id)); ?>" class="bg-white rounded-lg shadow p-6 mb-8">
      <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
      <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
        <label class="block">
          <span class="text-sm text-gray-600">Name</span>
          <input name="name" value="<?php echo e(old('name', $country->name)); ?>" class="mt-1 w-full border rounded p-2" required>
          <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-red-600 text-sm mt-1"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </label>
        <label class="block">
          <span class="text-sm text-gray-600">ISO2</span>
          <input name="iso2" value="<?php echo e(old('iso2', $country->iso2 ?? '')); ?>" class="mt-1 w-full border rounded p-2" maxlength="2">
          <?php $__errorArgs = ['iso2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-red-600 text-sm mt-1"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </label>
      </div>
      <div class="mt-4">
        <button class="px-4 py-2 rounded bg-indigo-600 text-white hover:bg-indigo-700">Save</button>
        <a href="<?php echo e(route('countries.index')); ?>" class="ml-2 text-gray-600 hover:underline">Back</a>
      </div>
    </form>

    
    <div class="bg-white rounded-lg shadow p-6">
      <h3 class="font-semibold mb-3">Mobile Country Codes (MCCs)</h3>

      <?php
        // Expecting $mccs as array; if not present, compute safely
        $mccs = (isset($mccs) && is_array($mccs)) ? $mccs
              : \Illuminate\Support\Facades\DB::table('country_mccs')->where('country_id', $country->id)->orderBy('mcc')->pluck('mcc')->toArray();
      ?>

      <div class="flex flex-wrap gap-2 mb-4">
        <?php $__empty_1 = true; $__currentLoopData = $mccs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
          <span class="inline-flex items-center gap-2 bg-gray-100 rounded px-2 py-1 text-sm">
            <span class="font-mono"><?php echo e($m); ?></span>
            <form method="POST" action="<?php echo e(route('countries.mccs.destroy', [$country->id, $m])); ?>" onsubmit="return confirm('Remove MCC <?php echo e($m); ?>?')">
              <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
              <button class="text-red-600 hover:text-red-800" title="Remove">&times;</button>
            </form>
          </span>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
          <span class="text-gray-500">No MCCs yet.</span>
        <?php endif; ?>
      </div>

      <form method="POST" action="<?php echo e(route('countries.mccs.store', $country->id)); ?>" class="flex items-end gap-3">
        <?php echo csrf_field(); ?>
        <label>
          <span class="block text-sm text-gray-600">Add MCC</span>
          <input name="mcc" maxlength="3" class="border rounded p-2 w-24" placeholder="202" value="<?php echo e(old('mcc')); ?>">
        </label>
        <button class="px-3 py-2 rounded bg-gray-800 text-white hover:bg-black">Add</button>
      </form>
      <?php $__errorArgs = ['mcc'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-red-600 text-sm mt-2"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
  </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>


<div class="mt-8 p-4 border rounded bg-white">
  <h3 class="font-semibold mb-2">Μεταφορά MCC σε άλλη χώρα</h3>

  <?php if(session('error')): ?>
    <div class="bg-red-100 text-red-800 text-sm p-2 rounded mb-2"><?php echo e(session('error')); ?></div>
  <?php endif; ?>
  <?php if(session('status')): ?>
    <div class="bg-green-100 text-green-800 text-sm p-2 rounded mb-2"><?php echo e(session('status')); ?></div>
  <?php endif; ?>
  <?php if(session('log')): ?>
    <details open class="mb-3">
      <summary class="cursor-pointer font-medium">Λεπτομέρειες</summary>
      <ul class="list-disc pl-5">
        <?php $__currentLoopData = (array) session('log'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $line): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <li><?php echo e($line); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </ul>
    </details>
  <?php endif; ?>

  <?php
    $mccRows = \Illuminate\Support\Facades\DB::table('country_mccs')->where('country_id',$country->id)->orderBy('mcc')->get();
    $allCountries = \App\Models\Country::orderBy('name')->get();
  ?>

  <form method="POST" action="<?php echo e(route('countries.mccs.reassign', ['country'=>$country->id])); ?>" class="grid grid-cols-1 md:grid-cols-3 gap-3">
    <?php echo csrf_field(); ?>
    <div>
      <label class="block text-sm font-medium mb-1">MCC προς μεταφορά</label>
      <select name="mcc" class="border rounded w-full p-2" required>
        <option value="" disabled selected>— επίλεξε MCC —</option>
        <?php $__currentLoopData = $mccRows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option value="<?php echo e($r->mcc); ?>"><?php echo e($r->mcc); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>
    </div>
    <div>
      <label class="block text-sm font-medium mb-1">Νέα χώρα</label>
      <select name="target_country_id" class="border rounded w-full p-2" required>
        <option value="" disabled selected>— επίλεξε χώρα —</option>
        <?php $__currentLoopData = $allCountries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option value="<?php echo e($c->id); ?>"><?php echo e($c->name); ?> (<?php echo e($c->id); ?>)</option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>
    </div>
    <div class="flex items-end">
      <button class="px-3 py-2 bg-blue-600 text-white rounded hover:bg-blue-700">Μεταφορά</button>
    </div>
  </form>
</div>
<?php /**PATH /var/www/html/resources/views/countries/edit.blade.php ENDPATH**/ ?>