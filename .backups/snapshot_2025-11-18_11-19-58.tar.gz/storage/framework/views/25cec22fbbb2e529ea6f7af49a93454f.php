<div class="mb-2">
  <div class="px-3 py-2 text-xs uppercase tracking-wide text-gray-500">Catalogs</div>
  <a href="<?php echo e(route('countries.index')); ?>" class="flex items-center gap-2 px-3 py-2 rounded hover:bg-gray-100">
    <span>Countries</span>
  </a>
  <a href="<?php echo e(route('networks.index')); ?>" class="flex items-center gap-2 px-3 py-2 rounded hover:bg-gray-100">
    <span>Networks</span>
  </a>
</div>
<?php /**PATH /var/www/html/resources/views/partials/catalog_links.blade.php ENDPATH**/ ?>