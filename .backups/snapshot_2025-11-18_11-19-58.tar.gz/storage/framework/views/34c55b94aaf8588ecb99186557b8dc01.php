<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
 <?php $__env->slot('header', null, []); ?> <h2 class="font-semibold text-xl text-gray-800">New User</h2> <?php $__env->endSlot(); ?>
<div class="py-6"><div class="max-w-2xl mx-auto sm:px-6 lg:px-8"><div class="bg-white p-6 shadow sm:rounded-lg">
    <form method="POST" action="<?php echo e(route('admin.users.store')); ?>" class="space-y-4">
        <?php echo csrf_field(); ?>
        <div><label class="block">Name <input name="name" class="mt-1 w-full border rounded p-2" required></label></div>
        <div><label class="block">Email <input type="email" name="email" class="mt-1 w-full border rounded p-2" required></label></div>
        <div><label class="block">Password <input type="password" name="password" class="mt-1 w-full border rounded p-2" required></label></div>
        <div><label class="block">Confirm Password <input type="password" name="password_confirmation" class="mt-1 w-full border rounded p-2" required></label></div>
        <div class="flex items-center gap-2"><input type="checkbox" name="is_admin" value="1" id="is_admin"><label for="is_admin">Admin</label></div>
        <div class="pt-4"><button class="px-4 py-2 bg-indigo-600 text-white rounded">Save</button></div>
    </form>
</div></div></div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /var/www/html/resources/views/admin/users/create.blade.php ENDPATH**/ ?>