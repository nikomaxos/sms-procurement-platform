<?php if(session('status')): ?>
  <div class="mb-4 rounded border border-green-200 bg-green-50 p-3 text-green-800">
    <?php echo e(session('status')); ?>

  </div>
<?php endif; ?>

<?php if($errors->any()): ?>
  <div class="mb-4 rounded border border-red-200 bg-red-50 p-3 text-red-800">
    <div class="font-semibold">Validation errors</div>
    <ul class="mt-2 list-disc list-inside">
      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($error); ?></li>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
  </div>
<?php endif; ?>

<?php if(session('log')): ?>
  <div class="mb-4 rounded border bg-gray-50 p-3">
    <div class="font-semibold text-gray-800">Log</div>
    <ul class="mt-2 space-y-1">
      <?php $__currentLoopData = session('log'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php $lvl = $entry['level'] ?? 'info'; ?>
        <li class="<?php if($lvl==='error'): ?> text-red-700 <?php elseif($lvl==='success'): ?> text-green-700 <?php else: ?> text-gray-800 <?php endif; ?>">
          <?php echo e($entry['msg'] ?? ''); ?>

        </li>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
  </div>
<?php endif; ?>
<?php /**PATH /var/www/html/resources/views/components/flash-log.blade.php ENDPATH**/ ?>