<?php if(auth()->guard()->check()): ?>
<nav style="background:#f9fafb;border-bottom:1px solid #e5e7eb;padding:10px 16px">
  <a href="<?php echo e(route('dashboard')); ?>" style="text-decoration:none;color:#111827">⚙️ Settings</a>
</nav>
<?php endif; ?>
<?php /**PATH /var/www/html/resources/views/partials/settings_nav.blade.php ENDPATH**/ ?>