<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
   <?php $__env->slot('header', null, []); ?> <h2 class="font-semibold text-xl text-gray-800 leading-tight">Edit Network</h2> <?php $__env->endSlot(); ?>
  <div class="py-6 max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
    <?php echo $__env->make('partials.flash_log', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <form method="POST" action="<?php echo e(route('networks.update', $network->id)); ?>" class="bg-white rounded shadow p-4 mb-6">
      <?php echo method_field('PUT'); ?>
      <?php echo $__env->make('networks._form', ['network' => $network], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
      <div class="mt-4">
        <button class="rounded bg-blue-600 text-white px-4 py-2" type="submit">Save</button>
        <a class="ml-3 text-gray-600 hover:underline" href="<?php echo e(route('networks.index')); ?>">Back</a>
      </div>
    </form>

    <div class="bg-white rounded shadow p-4">
      <div class="font-semibold mb-2">MNCs</div>
      <form class="mb-3 flex flex-wrap items-center gap-2" method="POST" action="<?php echo e(route('networks.mncs.store', $network->id)); ?>">
        <?php echo csrf_field(); ?>
        <div>
          <label class="block text-xs text-gray-500 mb-1">MCC</label>
          <input class="border rounded p-2 w-28 bg-gray-100" type="text" id="nf_mcc_display_clone" readonly>
          <input type="hidden" name="mcc" id="nf_mcc_hidden">
        </div>
        <div>
          <label class="block text-xs text-gray-500 mb-1">MNC</label>
          <input class="border rounded p-2 w-24" type="text" name="mnc" placeholder="MNC" required>
        </div>
        <div><button class="rounded bg-gray-800 text-white px-3 py-2" type="submit" id="nf_add_btn" disabled>Add</button></div>
      </form>

      <?php $links = $network->mncs()->orderBy('mcc')->orderBy('mnc')->get(); ?>
      <?php $__empty_1 = true; $__currentLoopData = $links; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <form method="POST" class="inline-block mr-2 mb-2"
              action="<?php echo e(route('networks.mncs.destroy', [$network->id, $link->mcc, $link->mnc])); ?>">
          <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
          <button class="inline-flex items-center gap-2 px-2 py-1 text-xs rounded bg-gray-100 border"
                  title="Remove" onclick="return confirm('Remove <?php echo e($link->mcc); ?>-<?php echo e($link->mnc); ?> ?');">
            <?php echo e($link->mcc); ?>-<?php echo e($link->mnc); ?> <span aria-hidden="true">✕</span>
          </button>
        </form>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <span class="text-gray-400">No MNCs</span>
      <?php endif; ?>
    </div>
  </div>

  <script>
  (function syncMccForAddForm(){
    const src = document.getElementById('nf_mcc_display');
    const sel = document.getElementById('nf_selected_mcc');
    const clone = document.getElementById('nf_mcc_display_clone');
    const hidden = document.getElementById('nf_mcc_hidden');
    const btn = document.getElementById('nf_add_btn');
    function tick(){
      const m = sel && sel.value ? sel.value : (src ? src.value : '');
      if(clone) clone.value = m || '';
      if(hidden) hidden.value = m || '';
      if(btn) btn.disabled = !m;
    }
    tick();
    setInterval(tick, 250);
  })();
  </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /var/www/html/resources/views/networks/edit.blade.php ENDPATH**/ ?>