<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
   <?php $__env->slot('header', null, []); ?> 
    <h2 class="font-semibold text-xl text-gray-800 leading-tight">Networks</h2>
   <?php $__env->endSlot(); ?>

  <div class="py-6 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
    <?php if ($__env->exists('partials.flash_log')) echo $__env->make('partials.flash_log', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <form method="GET" action="<?php echo e(route('networks.index')); ?>" class="bg-white rounded shadow p-4 mb-4">
      <div class="grid grid-cols-1 md:grid-cols-4 gap-3 items-end">
        <div class="md:col-span-2">
          <label class="block text-sm font-medium mb-1">Search name</label>
          <input class="border rounded w-full p-2" type="text" name="q" value="<?php echo e($filters['q'] ?? ''); ?>" placeholder="e.g. Cosmote">
        </div>

        <div>
          <label class="block text-sm font-medium mb-1">Country</label>
          <div class="relative">
            <input id="fi_country" class="border rounded w-full p-2" type="text" autocomplete="off"
                   placeholder="Type to search..."
                   value="<?php echo e($filters['country_name'] ?? ''); ?>">
            <input type="hidden" name="country_id" id="fi_country_id" value="<?php echo e($filters['country_id'] ?? ''); ?>">
            <div id="fi_results" class="hidden absolute z-10 mt-1 w-full bg-white border rounded shadow max-h-64 overflow-auto"></div>
          </div>
        </div>

        <div>
          <label class="block text-sm font-medium mb-1">Per page</label>
          <select class="border rounded w-full p-2" name="per_page">
            <?php $__currentLoopData = [20,50,100]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($n); ?>" <?php if(($filters['per_page'] ?? 20)==$n): echo 'selected'; endif; ?>><?php echo e($n); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
        </div>
      </div>

      <div class="mt-3 flex flex-wrap gap-2">
        <button class="rounded bg-blue-600 text-white px-4 py-2" type="submit">Filter</button>
        <a class="rounded bg-gray-100 px-4 py-2 border" href="<?php echo e(route('networks.index')); ?>">Clear</a>
        <a class="rounded bg-gray-800 text-white px-4 py-2"
           href="<?php echo e(route('networks.index', array_merge(request()->query(), ['export' => 'csv']))); ?>">
           Export CSV
        </a>
      </div>
    </form>

    <div class="bg-white rounded shadow overflow-x-auto">
      <table class="min-w-full text-sm">
        <thead class="bg-gray-50">
          <tr>
            <th class="text-left px-4 py-2">Name</th>
            <th class="text-left px-4 py-2">Country</th>
            <th class="text-left px-4 py-2">MCCs</th>
            <th class="text-left px-4 py-2">MNCs</th>
            <th class="text-left px-4 py-2">Actions</th>
          </tr>
        </thead>
        <tbody>
          <?php $__currentLoopData = $networks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class="border-t">
              <td class="px-4 py-2"><?php echo e($n->name); ?></td>
              <td class="px-4 py-2"><?php echo e($n->country->name ?? $n->country_id); ?></td>
              <td class="px-4 py-2">
                <?php $mccs = isset($mccsMap[$n->id]) ? explode(",", $mccsMap[$n->id]) : []; ?>
                <?php $__empty_1 = true; $__currentLoopData = $mccs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                  <span class="inline-block text-xs bg-gray-100 border rounded px-2 py-0.5 mr-1 mb-1"><?php echo e($m); ?></span>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                  <span class="text-gray-400">—</span>
                <?php endif; ?>
              </td>
              <td class="px-4 py-2"><?php echo e($n->mncs_count); ?></td>
              <td class="px-4 py-2">
                <a class="text-blue-700 hover:underline" href="<?php echo e(route('networks.edit', $n->id)); ?>">Edit</a>
              </td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>

    <div class="mt-4"><?php echo e($networks->links()); ?></div>
  </div>

  <script>
  (function(){
    const root = document;
    const box = root.getElementById('fi_results');
    const input = root.getElementById('fi_country');
    const hidden = root.getElementById('fi_country_id');
    if(!input || !box) return;

    const show = (rows)=>{
      box.innerHTML = '';
      if(!rows || !rows.length){ box.classList.add('hidden'); return; }
      rows.forEach(r=>{
        const d = document.createElement('div');
        const mcc = (r.mccs && r.mccs.length) ? ` (MCC: ${r.mccs.join(', ')})` : '';
        d.textContent = r.name + mcc;
        d.className = 'px-3 py-2 hover:bg-gray-50 cursor-pointer';
        d.addEventListener('click', ()=>{
          input.value = r.name;
          hidden.value = r.id;
          box.classList.add('hidden');
        });
        box.appendChild(d);
      });
      box.classList.remove('hidden');
    };

    let last = [];
    async function search(q){
      try{
        const r = await fetch(`/api/countries/search?q=${encodeURIComponent(q)}&limit=20`);
        if(!r.ok){ box.classList.add('hidden'); return; }
        last = await r.json();
        show(last);
      }catch(_e){ box.classList.add('hidden'); }
    }

    input.addEventListener('input', e=>{
      const q = e.target.value.trim();
      if(!q){ box.classList.add('hidden'); hidden.value = ''; return; }
      search(q);
    });
    input.addEventListener('focus', ()=>{ if(last.length) box.classList.remove('hidden'); });
    document.addEventListener('click', e=>{ if(!box.contains(e.target) && e.target!==input) box.classList.add('hidden'); });
    input.addEventListener('keydown', e=>{ if(e.key==='Escape') box.classList.add('hidden'); });
  })();
  </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /var/www/html/resources/views/networks/index.blade.php ENDPATH**/ ?>