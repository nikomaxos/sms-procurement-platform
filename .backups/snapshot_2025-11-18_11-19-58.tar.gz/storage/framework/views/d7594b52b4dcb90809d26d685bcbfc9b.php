<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['mnc']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['mnc']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $mcc = str_pad((string)($mnc->mcc ?? ''), 3, '0', STR_PAD_LEFT);
    $mncCode = str_pad((string)($mnc->mnc ?? ''), 3, '0', STR_PAD_LEFT);
    $src = $mnc->updated_by_source ?? $mnc->created_by_source ?? null;
    $title = "MCC {$mcc} / MNC {$mncCode}" . ($src ? " — source: {$src}" : "");
?>

<span
  class="inline-flex items-center gap-1 px-2 py-0.5 rounded border bg-white text-gray-700 text-xs"
  title="<?php echo e($title); ?>"
>
  <span class="font-mono"><?php echo e($mcc); ?>-<?php echo e($mncCode); ?></span>
  <?php if($src): ?>
    <span class="opacity-60">(<?php echo e($src); ?>)</span>
  <?php endif; ?>
</span>
<?php /**PATH /var/www/html/resources/views/components/mnc-row.blade.php ENDPATH**/ ?>