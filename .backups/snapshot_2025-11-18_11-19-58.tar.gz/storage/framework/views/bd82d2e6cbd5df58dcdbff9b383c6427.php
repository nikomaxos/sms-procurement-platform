<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
   <?php $__env->slot('header', null, []); ?> 
    <h2 class="font-semibold text-xl text-gray-800 leading-tight">Network Duplicates</h2>
   <?php $__env->endSlot(); ?>

  <div class="py-6 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
    <?php if(session('error')): ?>
      <div class="p-3 rounded bg-red-100 text-red-800"><?php echo e(session('error')); ?></div>
    <?php endif; ?>
    <?php if(session('status')): ?>
      <div class="p-3 rounded bg-green-100 text-green-800"><?php echo e(session('status')); ?></div>
    <?php endif; ?>
    <?php if(session('log')): ?>
      <pre class="p-3 rounded bg-gray-100 text-xs overflow-auto"><?php echo e(json_encode(session('log'), JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE)); ?></pre>
    <?php endif; ?>

    <div class="space-y-6">
      <h3 class="text-lg font-semibold">1) Duplicates by MCC+MNC</h3>
      <?php $__empty_1 = true; $__currentLoopData = $dupByPair; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <?php $nets = json_decode($grp->nets ?? '[]', true) ?: []; ?>
        <div class="border rounded p-3 bg-white">
          <div class="mb-2">
            <span class="font-mono text-sm px-2 py-1 bg-gray-100 rounded">MCC <?php echo e($grp->mcc); ?> / MNC <?php echo e($grp->mnc); ?></span>
            <span class="ml-2 text-sm text-gray-500">(<?php echo e($grp->c); ?> entries)</span>
          </div>

          <form method="POST" action="<?php echo e(route('networks.duplicates.merge')); ?>" class="space-y-2">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="reason" value="merge-by-mcc-mnc <?php echo e($grp->mcc); ?>-<?php echo e($grp->mnc); ?>">
            <div class="grid grid-cols-1 md:grid-cols-2 gap-2">
              <?php $__currentLoopData = $nets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <label class="flex items-center gap-2 border rounded p-2">
                  <input type="radio" name="target_id" value="<?php echo e($n['id']); ?>" <?php echo e($i===0 ? 'checked' : ''); ?>>
                  <input type="checkbox" name="source_ids[]" value="<?php echo e($n['id']); ?>" <?php echo e($i!==0 ? 'checked' : ''); ?>>
                  <span class="text-sm">
                    <span class="font-semibold"><?php echo e($n['name']); ?></span>
                    <span class="text-gray-500">— <?php echo e($n['id']); ?></span>
                    <span class="ml-1 text-gray-400">[<?php echo e($n['country'] ?? ''); ?>]</span>
                  </span>
                </label>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="text-right">
              <button class="px-3 py-1 rounded bg-blue-600 text-white">Merge into selected</button>
            </div>
          </form>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="text-sm text-gray-500">No duplicates by MCC/MNC detected.</div>
      <?php endif; ?>
    </div>

    <div class="space-y-6">
      <h3 class="text-lg font-semibold">2) Duplicates by Country + Name</h3>
      <?php $__empty_1 = true; $__currentLoopData = $dupByName; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <?php $nets = json_decode($grp->nets ?? '[]', true) ?: []; ?>
        <div class="border rounded p-3 bg-white">
          <div class="mb-2">
            <span class="font-mono text-sm px-2 py-1 bg-gray-100 rounded"><?php echo e($grp->country); ?></span>
            <span class="ml-2 text-sm text-gray-500">name: “<?php echo e($grp->lname); ?>” (<?php echo e($grp->c); ?> entries)</span>
          </div>

          <form method="POST" action="<?php echo e(route('networks.duplicates.merge')); ?>" class="space-y-2">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="reason" value="merge-by-name country=<?php echo e($grp->country); ?> name=<?php echo e($grp->lname); ?>">
            <div class="grid grid-cols-1 md:grid-cols-2 gap-2">
              <?php $__currentLoopData = $nets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <label class="flex items-center gap-2 border rounded p-2">
                  <input type="radio" name="target_id" value="<?php echo e($n['id']); ?>" <?php echo e($i===0 ? 'checked' : ''); ?>>
                  <input type="checkbox" name="source_ids[]" value="<?php echo e($n['id']); ?>" <?php echo e($i!==0 ? 'checked' : ''); ?>>
                  <span class="text-sm">
                    <span class="font-semibold"><?php echo e($n['name']); ?></span>
                    <span class="text-gray-500">— <?php echo e($n['id']); ?></span>
                  </span>
                </label>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="text-right">
              <button class="px-3 py-1 rounded bg-blue-600 text-white">Merge into selected</button>
            </div>
          </form>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="text-sm text-gray-500">No duplicates by Country+Name detected.</div>
      <?php endif; ?>
    </div>
  </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /var/www/html/resources/views/networks/duplicates.blade.php ENDPATH**/ ?>