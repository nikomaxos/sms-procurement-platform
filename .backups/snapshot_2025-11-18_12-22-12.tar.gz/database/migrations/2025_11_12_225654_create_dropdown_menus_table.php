<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void {
        if (!Schema::hasTable('dropdown_menus')) {
            Schema::create('dropdown_menus', function (Blueprint $table) {
                $table->id();
                $table->string('title', 120);
                $table->timestamps();
            });
        }
    }
    public function down(): void {
        Schema::dropIfExists('dropdown_menus');
    }
};
